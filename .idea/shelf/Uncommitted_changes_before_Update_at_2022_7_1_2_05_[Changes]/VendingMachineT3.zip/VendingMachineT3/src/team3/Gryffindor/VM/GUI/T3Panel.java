package team3.Gryffindor.VM.GUI;

import javax.swing.*;

public class T3Panel extends JPanel {
}
