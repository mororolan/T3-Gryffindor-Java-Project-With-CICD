import team3.Gryffindor.VM.panel.SimulatorControlPanel;

public class Main {

    public static void main(String[] args) {
        boolean loginStatus = false;
        new SimulatorControlPanel("VMCS - Simulator Control Panel - By Team #3",loginStatus);
    }
}

