package team3.Gryffindor.VM;

import javax.swing.*;

import static org.junit.Assert.*;

public class MaintainerPanelTest {
//    @Test
//    void testOpenMaintainerFrame() {
//        JFrame maintainerFrame = new MaintainerLoginFrame();
//        String maintainerFrameTitle = "Test Maintainer Panel";
//        ((MaintainerLoginFrame) maintainerFrame).createMaintainerJFrame(maintainerFrameTitle);
//    }
//
//    @Test
//    void testGetTotalCash() {
//        MaintainerFileManager mfm = new MaintainerFileManager();
//        int totalCash = mfm.getTotalCash("./maintainerData/coins.csv");
//        assertEquals(totalCash,5380);
//    }
}